from flask import Flask, render_template, request, redirect, session, jsonify
import json, os
from datetime import date

app = Flask(__name__)
app.secret_key = "CHANGE_ME"

BASE = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE, "data.json")
OLD_FILE = os.path.join(BASE, "old_records.json")
CRED_FILE = os.path.join(BASE, "credentials.json")
LAST_RESET = os.path.join(BASE, "last_reset.txt")

# -------------------------------------------------
# Helper functions
# -------------------------------------------------

def load_json(path):
    try:
        with open(path, "r") as f:
            return json.load(f)
    except:
        return {}

def save_json(path, data):
    with open(path, "w") as f:
        json.dump(data, f, indent=4)

# -------------------------------------------------
# Initialize required files
# -------------------------------------------------

EMPTY_TEMPLATE = {
    "bangla_ff": {
        "r2": ["-"] * 8,
        "r3": ["-"] * 8
    },
    "ff_kolkata": {
        "r2": ["-"] * 8,
        "r3": ["-"] * 8
    },
    "main_bazar": {
        "market": "MAIN BAZAR",
        "open": "",
        "close": "",
        "r1": ["-", "-"],
        "r2": ["-", "-"]
    },
    "pk_mumbai": {
        "market": "PK MAIN MUMBAI",
        "open": "",
        "close": "",
        "r1": ["-", "-"],
        "r2": ["-", "-"]
    }
}

def init_files():
    if not os.path.exists(DATA_FILE):
        save_json(DATA_FILE, EMPTY_TEMPLATE)

    if not os.path.exists(OLD_FILE):
        save_json(OLD_FILE, [])

    if not os.path.exists(CRED_FILE):
        save_json(CRED_FILE, {"username": "admin", "password": "1234"})

    if not os.path.exists(LAST_RESET):
        with open(LAST_RESET, "w") as f:
            f.write(date.today().isoformat())

init_files()

# -------------------------------------------------
# Daily Reset
# -------------------------------------------------

def daily_reset():
    today = date.today().isoformat()

    with open(LAST_RESET, "r") as f:
        last = f.read().strip()

    if last != today:
        old_data = load_json(DATA_FILE)
        history = load_json(OLD_FILE)

        history.insert(0, {"date": last, "data": old_data})
        save_json(OLD_FILE, history[:200])  # keep last 200 days

        save_json(DATA_FILE, EMPTY_TEMPLATE)

        with open(LAST_RESET, "w") as f:
            f.write(today)

# -------------------------------------------------
# Public Routes
# -------------------------------------------------

@app.route("/")
def frontend():
    daily_reset()
    data = load_json(DATA_FILE)
    return render_template("index.html", data=data)

@app.route("/get-data")
def get_data():
    daily_reset()
    return jsonify(load_json(DATA_FILE))

@app.route("/old-records")
def old_records():
    return render_template("old_records.html", history=load_json(OLD_FILE))

# -------------------------------------------------
# Admin Login
# -------------------------------------------------

@app.route("/admin-login", methods=["GET", "POST"])
def admin_login():
    creds = load_json(CRED_FILE)
    error = None

    if request.method == "POST":
        u = request.form.get("username")
        p = request.form.get("password")

        if u == creds["username"] and p == creds["password"]:
            session["admin"] = True
            return redirect("/admin/dashboard")
        else:
            error = "Invalid username or password"

    return render_template("admin_login.html", error=error)

@app.route("/admin/logout")
def logout():
    session.clear()
    return redirect("/admin-login")

# -------------------------------------------------
# Admin Dashboard
# -------------------------------------------------

@app.route("/admin/dashboard")
def dashboard():
    if not session.get("admin"):
        return redirect("/admin-login")

    data = load_json(DATA_FILE)
    return render_template("admin_dashboard.html", data=data)

# -------------------------------------------------
# Update Sections (Matches Your HTML Exactly)
# -------------------------------------------------

@app.route("/admin/update/bangla_ff", methods=["POST"])
def update_bangla():
    if not session.get("admin"):
        return redirect("/admin-login")

    data = load_json(DATA_FILE)

    r2 = request.form.get("r2", "").split(",")
    r3 = request.form.get("r3", "").split(",")

    data["bangla_ff"]["r2"] = [x.strip() for x in r2]
    data["bangla_ff"]["r3"] = [x.strip() for x in r3]

    save_json(DATA_FILE, data)
    return redirect("/admin/dashboard")

@app.route("/admin/update/main_bazar", methods=["POST"])
def update_main_bazar():
    if not session.get("admin"):
        return redirect("/admin-login")

    data = load_json(DATA_FILE)

    data["main_bazar"]["market"] = request.form.get("market")
    data["main_bazar"]["open"] = request.form.get("open")
    data["main_bazar"]["close"] = request.form.get("close")

    r1 = request.form.get("r1", "").split(",")
    r2 = request.form.get("r2", "").split(",")

    data["main_bazar"]["r1"] = [x.strip() for x in r1]
    data["main_bazar"]["r2"] = [x.strip() for x in r2]

    save_json(DATA_FILE, data)
    return redirect("/admin/dashboard")

@app.route("/admin/update/pk_mumbai", methods=["POST"])
def update_pk():
    if not session.get("admin"):
        return redirect("/admin-login")

    data = load_json(DATA_FILE)

    data["pk_mumbai"]["market"] = request.form.get("market")
    data["pk_mumbai"]["open"] = request.form.get("open")
    data["pk_mumbai"]["close"] = request.form.get("close")

    r1 = request.form.get("r1", "").split(",")
    r2 = request.form.get("r2", "").split(",")

    data["pk_mumbai"]["r1"] = [x.strip() for x in r1]
    data["pk_mumbai"]["r2"] = [x.strip() for x in r2]

    save_json(DATA_FILE, data)
    return redirect("/admin/dashboard")

@app.route("/admin/update/ff_kolkata", methods=["POST"])
def update_kolkata():
    if not session.get("admin"):
        return redirect("/admin-login")

    data = load_json(DATA_FILE)

    r2 = request.form.get("r2", "").split(",")
    r3 = request.form.get("r3", "").split(",")

    data["ff_kolkata"]["r2"] = [x.strip() for x in r2]
    data["ff_kolkata"]["r3"] = [x.strip() for x in r3]

    save_json(DATA_FILE, data)
    return redirect("/admin/dashboard")

# -------------------------------------------------
# Update Admin Credentials
# -------------------------------------------------

@app.route("/admin/update-credentials", methods=["POST"])
def update_credentials():
    if not session.get("admin"):
        return redirect("/admin-login")

    new_user = request.form.get("new_username")
    new_pass = request.form.get("new_password")

    save_json(CRED_FILE, {"username": new_user, "password": new_pass})

    return redirect("/admin/dashboard")

# -------------------------------------------------
# Run Server
# -------------------------------------------------

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0")
