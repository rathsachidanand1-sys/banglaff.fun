// Set date
(function setDate(){
  const today = new Date();
  const text = today.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric'});
  document.getElementById('mainDate').innerText = text;
  document.getElementById('mbDate').innerText = text;
  document.getElementById('pkDate').innerText = text;
  document.getElementById('kolDate').innerText = text;
})();


// Fetch and render data
fetch('/get-data').then(r=>r.json()).then(data=>{
  if(data.bangla_ff){
    document.getElementById('ownerRow1').innerHTML = data.bangla_ff.r2.map(v=>`<td>${v}</td>`).join('');
    document.getElementById('ownerRow2').innerHTML = data.bangla_ff.r3.map(v=>`<td>${v}</td>`).join('');
  }
  if(data.main_bazar){
    const mb=data.main_bazar;
    document.getElementById('marketName1').innerText=mb.market;
    document.getElementById('openTime1').innerText=mb.open;
    document.getElementById('closeTime1').innerText=mb.close;
    document.getElementById('mb_adminRow1').innerHTML = `<div class="col">${mb.r1[0]}</div><div class="col">${mb.r1[1]}</div>`;
    document.getElementById('mb_adminRow2').innerHTML = `<div class="col">${mb.r2[0]}</div><div class="col">${mb.r2[1]}</div>`;
  }
  if(data.pk_mumbai){
    const pk=data.pk_mumbai;
    document.getElementById('marketName2').innerText=pk.market;
    document.getElementById('openTime2').innerText=pk.open;
    document.getElementById('closeTime2').innerText=pk.close;
    document.getElementById('pk_adminRow1').innerHTML = `<div class="col">${pk.r1[0]}</div><div class="col">${pk.r1[1]}</div>`;
    document.getElementById('pk_adminRow2').innerHTML = `<div class="col">${pk.r2[0]}</div><div class="col">${pk.r2[1]}</div>`;
  }
  if(data.ff_kolkata){
    document.getElementById('kol_row2').innerHTML = data.ff_kolkata.r2.map(v=>`<td>${v}</td>`).join('');
    document.getElementById('kol_row3').innerHTML = data.ff_kolkata.r3.map(v=>`<td>${v}</td>`).join('');
  }
}).catch(err=>console.error(err));

document.querySelector('.refresh')?.addEventListener('click',()=>location.reload());
document.querySelector('.old-record')?.addEventListener('click',()=>window.location='/old-records');

// Set next result time (example: after 5 hours)
let nextResultTime = new Date();
nextResultTime.setHours(nextResultTime.getHours() + 5);

// Helper: add leading zero
function pad(n){
  return String(n).padStart(2, '0');
}

function updateFlipCountdown(){
  const now = new Date();
  let diff = Math.max(0, nextResultTime - now);

  const days = Math.floor(diff / (1000*60*60*24));
  diff -= days * (1000*60*60*24);

  const hours = Math.floor(diff / (1000*60*60));
  diff -= hours * (1000*60*60);

  const mins = Math.floor(diff / (1000*60));
  diff -= mins * (1000*60);

  const secs = Math.floor(diff / 1000);

  document.getElementById('daysT').innerText = pad(days);
  document.getElementById('hoursT').innerText = pad(hours);
  document.getElementById('minsT').innerText = pad(mins);
  document.getElementById('secsT').innerText = pad(secs);
}

// Update every second
setInterval(updateFlipCountdown, 1000);
updateFlipCountdown();
